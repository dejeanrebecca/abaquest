
  # Design AbaQuest Learning App

  This is a code bundle for Design AbaQuest Learning App. The original project is available at https://www.figma.com/design/y3tadsMQhPBo4DzmGY8rHf/Design-AbaQuest-Learning-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  